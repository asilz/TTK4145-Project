# TTK4145-Project

# Build
This project supports linux with gcc only. Open a terminal in the project root and type the following:
```
mkdir build
cd build
cmake ..
make
```
This will generate an executable with the name elevator.