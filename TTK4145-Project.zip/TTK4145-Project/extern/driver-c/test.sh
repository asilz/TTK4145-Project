#!/bin/bash
gcc elevator_hardware.c elevator_hardware_test.c -o elevator_test
./elevator_test


